<link rel="stylesheet" href="{{asset('css/courses.css')}}">

@extends('master.main')

@section('content')

@component('components.courses.add-form')
    
@endcomponent



@endsection
