<div class="dashboard-card {{$backgroundClass}}" onclick="location.href = '{{$dir}}'">
    <div class="left">
        <h1>{{$count}}</h1>
        <p>{{$name}}</p>
    </div>
    <div class="right">
        <i class="{{$iconClass}}"></i>
    </div>
</div>
