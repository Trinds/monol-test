<div class="student-card">
    <h1><?php echo e($student->name); ?></h1>
    <?php if($student->image): ?>
        <img class='user-img' src='<?php echo e($student->image); ?>' alt='User Profile Picture'>
    <?php else: ?>
        <i class='fa-regular fa-circle-user user-img'></i>
    <?php endif; ?>
    <label>Email:<input type="text" value="<?php echo e($student->email); ?>" disabled></label>
    <label>Turma:<input type="text" value="<?php echo e($student->classroom->course->abbreviation . $student->classroom->edition); ?>" disabled></label>
    <label>Nº Aluno:<input type="text" value="<?php echo e($student->student_number); ?>" disabled></label>
    <label>Data de nascimento:<input type="text" value="<?php echo e(date('d-m-Y', strtotime($student->birth_date))); ?>" disabled></label>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/students/student-card.blade.php ENDPATH**/ ?>