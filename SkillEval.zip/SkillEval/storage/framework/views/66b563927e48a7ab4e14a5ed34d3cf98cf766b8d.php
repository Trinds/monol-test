<div class="container">        

    <form action="<?php echo e(url('classrooms')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h1>Adicionar Turma</h1>

        <fieldset>
        <legend><span class="number">1</span> Informação do Curso</legend>
        <label for="course_id">Curso:</label>
        <select name="course_id" id="course_id" class="form-control">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($course->id); ?>"><?php echo e($course->abbreviation); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </fieldset>

        <fieldset>
            <legend><span class="number">2</span> Informação da Turma</legend>

            <label for="edition">Edição:</label>
            <input type="text" id="edition" name="edition" class="form-control"
            placeholder="Edição da turma"
            <?php $__errorArgs = ['edition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            value="<?php echo e(old('edition')); ?>"
            required
            aria-describedat="editionHelp">
            <small id="editionHelp" class="form-text text-muted">Ex: 2021/2022</small>
          
            <label for="start_date">Data de começo:</label>
            <input type="date" id="start_date" name="start_date"
            class="form-control"
            placeholder="Data de começo da turma"
            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            required
            aria-describedat="start_dateHelp">
            <small id="start_dateHelp" class="form-text text-muted">Ex: 2021-09-01</small>
        
            <label for="end_date">Data de conclusão:</label>
            <input type="date" id="end_date" name="end_date"
            class="form-control"
            placeholder="Data de conclusão da turma"
            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            required
            aria-describedat="end_dateHelp">
            <small id="end_dateHelp" class="form-text text-muted">Ex: 2022-06-30</small>
        </fieldset>
        <div class="form-group">
        <button type="submit">Adicionar</button>
        </div>
    </form>
</div><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/classrooms/add-form.blade.php ENDPATH**/ ?>