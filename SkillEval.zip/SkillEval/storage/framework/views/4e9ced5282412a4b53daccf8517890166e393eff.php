<div class="container">        

    <form action="<?php echo e(url('courses/' . $course->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <h1>Editar curso</h1>

        <fieldset>
            <legend><span class="number">1</span> Informação do Curso</legend>

            <label for="name">Nome:</label>
            <input type="text" id="name" name="name" class="form-control"
            placeholder="<?php echo e($course->name); ?>"
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            required
            value="<?php echo e($course->name); ?>"
            aria-describedat="nameHelp">
            <small id="nameHelp" class="form-text text-muted">Ex: Técnico Programação e Sistemas de Informação</small>
          
            <label for="abbreviation">Sigla:</label>
            <input type="text" id="abbreviation" name="abbreviation"
            class="form-control"
            placeholder="<?php echo e($course->abbreviation); ?>"
            <?php $__errorArgs = ['abbreviation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            value="<?php echo e($course->abbreviation); ?>"
            required
            aria-describedat="abbreviationHelp">
            <small id="abbreviationHelp" class="form-text text-muted">Ex: TPSI</small>
        
        </fieldset>

        <button type="submit">Editar</button>

    </form>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/courses/edit-form.blade.php ENDPATH**/ ?>