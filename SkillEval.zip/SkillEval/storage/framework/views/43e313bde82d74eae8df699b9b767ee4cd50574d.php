

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script type="module" src="<?php echo e(asset('js/createStudentChart.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/students.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="title">
        <h1>Detalhes do Aluno</h1>  
    </div>

    <div class="add-evaluation">
        <a href="<?php echo e(route('evaluations.create.student', $student->id)); ?>">Adicionar Avaliação<i class="fa-solid fa-plus-circle addBtn"></i></a>
    </div>

    <div class="grid-container">
        <div class="chart-container">
            <?php $__env->startComponent('components.students.evaluations-chart' , ['studentEvaluations'=>$student->evaluations]); ?>
            <?php if (isset($__componentOriginald94cb6c04cc2d13d7c588cd89fb0b6c516835e61)): ?>
<?php $component = $__componentOriginald94cb6c04cc2d13d7c588cd89fb0b6c516835e61; ?>
<?php unset($__componentOriginald94cb6c04cc2d13d7c588cd89fb0b6c516835e61); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>

        <div class="details-container">
            <?php $__env->startComponent('components.students.student-card' , ['student'=>$student]); ?>
            <?php if (isset($__componentOriginalcfb4383206732aaf710e85350c1623b8c3612b90)): ?>
<?php $component = $__componentOriginalcfb4383206732aaf710e85350c1623b8c3612b90; ?>
<?php unset($__componentOriginalcfb4383206732aaf710e85350c1623b8c3612b90); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>

        <div class="evaluations-container">
            <h1>Historico de avaliações</h1>
            <div class="table-container">
                <table>
                    <thead>
                    <tr class="table-header">
                        <th scope="col">ID</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Nota</th>
                        <th scope="col">Data</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $student->evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-row">
                            <td><?php echo e($evaluation->test->id); ?></td>
                            <td><?php echo e($evaluation->test->type->type); ?></td>
                            <td><?php echo e($evaluation->score); ?></td>
                            <td>
                                <?php if($evaluation->test->date): ?>
                                <?php echo e(date('d/m/Y', strtotime($evaluation->test->date))); ?>

                                <?php else: ?>
                                    Não realizado
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/students/show.blade.php ENDPATH**/ ?>