<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="<?php echo e(asset('css/reset.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
    <title>Login</title>
</head>
<body>
    <div class="login-background">
        <div class="login-card">
            <div class="app-title">
                <svg width="6" height="39" viewBox="0 0 6 39" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 0L3 39" stroke="#F8D442" stroke-width="6" />
                </svg>
                <h1>ATEC SkillEval</h1>
            </div>
            <form class="login-form" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <label class="login-form-input-name" for="email">Email
                    <input id="email" type="email" placeholder="Email" class="login-form-input-field form-control"
                        name="email" value="<?php echo e(old('email')); ?>" required autocomplete="off" autofocus>
                </label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label class="login-form-input-name" for="password">Password
                    <input id="password" type="password" placeholder="Password" class="login-form-input-field form-control"
                        name="password" required autocomplete="off">
                </label>
                <button type="submit" class="login-form-submit-button">Login</button>

                <div class="link-span">
                    <a href="<?php echo e(route('password.request')); ?>">Esqueceu-se da password?</a>
                </div>


            </form>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/auth/login.blade.php ENDPATH**/ ?>