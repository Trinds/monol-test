<aside class="side-menu">

    <div class="app-title">
        <svg width="6" height="39" viewBox="0 0 6 39" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 0L3 39" stroke="#F8D442" stroke-width="6"></path>
        </svg>
        <p>ATEC SkillEval</p>
    </div>
<ul id="userInfo">
    <?php if(Auth::user()): ?>
    <li>
        <?php if(Auth::user()->image !== null): ?>
        <div>
            <img src="<?php echo e(asset('storage/' . Auth::user()->image)); ?>" alt="<?php echo e(Auth::user()->name); ?> Profile Image">
        </div>
        <?php endif; ?>
    </li>
    <li id="userName">
        <p><?php echo e(Auth::user()->name); ?></p>
    </li>
    <li id="userRole">
        <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($role->name); ?> </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </li>
    <?php endif; ?>
</ul>
    <ul id="menu">
        <li onclick="goToHome()" id="toHome"><div class="icon"><i class="fa fa-home"></i></div>Início</li>
        <li onclick="goToCourses()" id="toCourses"><div class="icon"><i class="fa-regular fa-bookmark"></i></div>Cursos</li>
        <li onclick="goToClassrooms()" id="toClassrooms"><div class="icon"><i class="fa-solid fa-users"></i></div>Turmas</li>
        <li onclick="goToStudents()" id="toStudents"><div class="icon"><i class="fa-solid fa-user-graduate"></i></div>Formandos</li>

        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->roles->contains('name', 'admin')): ?>
        <li onclick="goToUsers()" id="toUsers">
            <div class="icon">
                <i class="fa-solid fa-id-card"></i>
            </div>Utlizadores
        </li>
        <?php endif; ?>
        <?php endif; ?>

        <li id="toReports"><div class="icon"><i class="fa fa-flag"></i></div>Relatórios</li>
        <li id="toEvaluations"><div class="icon"><i class="fa-solid fa-check"></i></div>Avaliações</li>
    </ul>

    <ul id="sair">
        <li id="toLogout"
        onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
            SAIR
            <div class="icon">
                <i class="fa-solid fa-arrow-right-from-bracket" ></i>
            </div>
        </li>
    </ul>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>


</aside>


<script type="text/javascript">
    function goToHome(){
        location.href = "<?php echo e(route('home')); ?>"
    }
    function goToCourses(){
        location.href = "<?php echo e(route('courses.index')); ?>"
    }
    function goToStudents(){
        location.href = "<?php echo e(route('students.index')); ?>"
    }
    function goToClassrooms(){
        location.href = "<?php echo e(route('classrooms.index')); ?>"
    }

    function goToUsers(){
        location.href = "<?php echo e(route('users.index')); ?>"
    }
</script>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/master/header.blade.php ENDPATH**/ ?>