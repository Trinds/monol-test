<link rel="stylesheet" href="<?php echo e(asset('css/courses.css')); ?>">


<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.classrooms.edit-form', ['courses' => $courses , 'classroom' => $classroom]); ?>
    
<?php if (isset($__componentOriginalef1c66290d73af886f5cf35e8ad2423a9fe40a83)): ?>
<?php $component = $__componentOriginalef1c66290d73af886f5cf35e8ad2423a9fe40a83; ?>
<?php unset($__componentOriginalef1c66290d73af886f5cf35e8ad2423a9fe40a83); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/classrooms/edit.blade.php ENDPATH**/ ?>