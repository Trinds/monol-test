<div class="title">
    <h1>Lista de Turmas</h1>
</div>
<div class="table-container">
    <table class="coursesTable">
        <thead>
        <tr class="table-header">
            <th scope="col">Curso</th>
            <th scope="col">Edição</th>
            <th scope="col">Data de Começo</th>
            <th scope="col">Data de Conclusão</th>
            <th scope="col"></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table-row">
                <td><?php echo e($classroom->course->abbreviation); ?></td>
                <td><?php echo e($classroom->edition); ?></td>
                <td><?php echo e($classroom->start_date); ?></td>
                <td><?php echo e($classroom->end_date); ?></td>
                <td>
                    <a href="<?php echo e(route('classrooms.show', $classroom->id)); ?>"><i class="fa-solid fa-magnifying-glass detailsBtn"></i></a>
                    <a href="<?php echo e(route('classrooms.edit', $classroom->id)); ?>"><i class="fa-solid fa-pencil editBtn"></i></a>
                    <a onclick="event.preventDefault();
                   document.getElementById('clasroomRmvForm').submit();">
                    <i class="fa-regular fa-trash-can removeBtn"></i>
                    </a>
                    <form id="clasroomRmvForm" action="<?php echo e(route('classrooms.destroy', $classroom->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/classrooms/table.blade.php ENDPATH**/ ?>