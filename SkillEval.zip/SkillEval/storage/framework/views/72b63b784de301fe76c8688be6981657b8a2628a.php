 

<?php $__env->startSection('content'); ?>

<h1>Adicionar Avaliação para 
    <a href="<?php echo e(route('students.show', $student)); ?>"><?php echo e($student->name); ?></a>
</h1>

<form action="<?php echo e(route('evaluations.store.student', $student)); ?>" method="POST">

    <?php echo csrf_field(); ?>
    <label for="test_id">Avaliação</label>
    <input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
    <select class="form-control" id="test_id" name="test_id">
        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($test->id); ?> <?php echo e(old('test_id')); ?>><?php echo e($test->type->type); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <label for="score">Nota</label>
    <input type="number" name="score" class="form-control" min="0" max="20" step="0.1">
    <button type="submit" class="btn btn-primary">Submeter</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/evaluations/create-for-student.blade.php ENDPATH**/ ?>