

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/courses.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/topbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('components.topbar',[
    'dir'=>'courses',
    'createBtnName'=>'Curso',
    ]); ?>
    <?php if (isset($__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14)): ?>
<?php $component = $__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14; ?>
<?php unset($__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.courses.table', ['courses' => $courses] ); ?>

    <?php if (isset($__componentOriginala1813d4e751042b0a8199ae9db1d6c430c65b220)): ?>
<?php $component = $__componentOriginala1813d4e751042b0a8199ae9db1d6c430c65b220; ?>
<?php unset($__componentOriginala1813d4e751042b0a8199ae9db1d6c430c65b220); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/courses/index.blade.php ENDPATH**/ ?>