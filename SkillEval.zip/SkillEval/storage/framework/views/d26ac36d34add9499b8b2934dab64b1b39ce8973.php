<div class="top-bar">
    <form method="get" action="/<?php echo e($dir); ?>">
        <?php echo csrf_field(); ?>
        <div class="search-input">
            <input type="search" name="searchParam" id="searchParam" class="custom-icon" placeholder="Pesquisar...">
        </div>
        <?php if(isset($filterName)): ?>
        <div>
            <label for="filter"><?php echo e($filterName); ?></label>
            <select class="form-control" id="filter" name="filter" onchange="this.form.submit()">
                <option onselect="<?php echo e(route($dir.'.index')); ?>" value="">Todos/as</option>
                <?php if( isset($classrooms) && $dir=='students' ): ?>
                    <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($classroom->id); ?> <?php echo e(request('filter') == $classroom->id ? 'selected' : ''); ?>><?php echo e($classroom->course->abbreviation . $classroom->edition); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if( isset($courses)  && $dir=='classrooms' ): ?>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($course->id); ?> <?php echo e(request('filter') == $course->id ? 'selected' : ''); ?>><?php echo e($course->abbreviation); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <?php endif; ?>
    </form>
    <button onclick="location.href = '<?php echo e(route($dir.'.create')); ?>'">Criar <?php echo e($createBtnName); ?></button>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/topbar.blade.php ENDPATH**/ ?>