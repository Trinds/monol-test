

    <?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/students.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/topbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <?php $__env->startComponent('components.topbar',[
    'dir'           => 'students',
    'createBtnName' => 'Aluno',
    'classrooms'    => $classrooms,
    'filterName'    => 'Turma'
     ]); ?>
    <?php if (isset($__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14)): ?>
<?php $component = $__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14; ?>
<?php unset($__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



    <?php $__env->startComponent('components.students.students-table', ['students' => $students] ); ?>
    <?php if (isset($__componentOriginal8a94404830c59b685e5aac7287b26400135690b9)): ?>
<?php $component = $__componentOriginal8a94404830c59b685e5aac7287b26400135690b9; ?>
<?php unset($__componentOriginal8a94404830c59b685e5aac7287b26400135690b9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/students/index.blade.php ENDPATH**/ ?>