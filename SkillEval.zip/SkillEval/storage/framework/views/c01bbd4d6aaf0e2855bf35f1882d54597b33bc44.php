<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<div class="container">
    <div class="heading mb-3">
        <h1><?php echo e($classroom->course->abbreviation); ?> <?php echo e($classroom->edition); ?></h1>
        <h5><?php echo e($classroom->course->name); ?></h5>
        <h6>Começo: <?php echo e($classroom->start_date); ?> <br>Fim: <?php echo e($classroom->end_date); ?></h6>
    </div>
    <div class="chart-container">
        <?php $__env->startComponent('components.classrooms.classroom-chart', ['classroom'=>$classroom]); ?>
        <?php if (isset($__componentOriginalf31e1cb547e064efe6c80b1caa3557d55ce6b32a)): ?>
<?php $component = $__componentOriginalf31e1cb547e064efe6c80b1caa3557d55ce6b32a; ?>
<?php unset($__componentOriginalf31e1cb547e064efe6c80b1caa3557d55ce6b32a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    </div>
    <div class="row">
        <?php if($classroom->students->count() == 0): ?>
            <div class="alert alert-info" role="alert">
                Ainda não existem alunos para esta turma.
            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $classroom->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="grid-card">
                <div class="grid-card-img">




                        <img src="<?php echo e(asset('imgs/student.png')); ?>" alt="<?php echo e($student->name); ?> Profile Image"/>

                </div>
                <div class="grid-card-details">
                    <p class="fw-bold mb-1"><?php echo e(isset($student) ?
                                                    implode(' ',[ explode(' ', $student->name)[0] , explode(' ', $student->name)[str_word_count($student->name)-1] ])
                                                    : $classroom->course->abbreviation .' ' . $classroom->edition); ?></p>
                    <p class="text-muted mb-0"><?php echo e(isset($student)? 'Número: ' . $student->student_number : 'Inicio: ' . $classroom->start_date); ?></p>
                    <p class="text-muted mb-0"><?php echo e(isset($student)? 'Email: ' . $student->email : 'Fim: ' . $classroom->end_date); ?> </p>
                    <?php echo e(!isset($student) && "<p class='text-muted mb-0'>Nº de alunos:" . $classroom->students->count() . "</p>"); ?>

                </div>
                <div class="grid-card-btns">
                    <a class="btn btn-link m-0 text-reset"
                       href="<?php echo e(route('classrooms.show', $classroom->id)); ?>"
                       role="button"
                       data-ripple-color="primary">Ver<i class="bi bi-search"></i></a>
                    <a class="btn btn-link m-0 text-reset"
                       href="<?php echo e(route('classrooms.edit', $classroom->id)); ?>"
                       role="button"
                       data-ripple-color="primary">Editar<i class="bi bi-pencil-fill"></i></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/classrooms/show-component.blade.php ENDPATH**/ ?>