<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="<?php echo e(asset('css/reset.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
    <title>Login</title>
</head>
<body>
    <div class="login-background">
        <div class="login-card">
            <div class="app-title">
                <svg width="6" height="39" viewBox="0 0 6 39" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 0L3 39" stroke="#F8D442" stroke-width="6" />
                </svg>
                <h1>Reset Password</h1>
            </div>  
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form class="login-form" method="POST" action="<?php echo e(route('password.email')); ?>">
                    <?php echo csrf_field(); ?>
                    <label for="email" class="login-form-input-name"><?php echo e(__('Enderço de e-mail')); ?></label>

                    <div class="col-md-6">
                        <input id="email" type="email" class="login-form-input-field form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
        

               
                    <div class="login-form-submit-button">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Enviar link de recuperação')); ?>

                        </button>
                </div>
            </form>
            </div>
        </div>
    </div>
    </div>
</body>
</html>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>