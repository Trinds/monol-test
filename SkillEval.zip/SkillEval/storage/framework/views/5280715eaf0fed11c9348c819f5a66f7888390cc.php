<link rel="stylesheet" href="<?php echo e(asset('css/courses.css')); ?>">



<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.courses.add-form'); ?>
    
<?php if (isset($__componentOriginale07161d6376c9f90cd0aa4b85971ab60fb8ae9b1)): ?>
<?php $component = $__componentOriginale07161d6376c9f90cd0aa4b85971ab60fb8ae9b1; ?>
<?php unset($__componentOriginale07161d6376c9f90cd0aa4b85971ab60fb8ae9b1); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/courses/create.blade.php ENDPATH**/ ?>