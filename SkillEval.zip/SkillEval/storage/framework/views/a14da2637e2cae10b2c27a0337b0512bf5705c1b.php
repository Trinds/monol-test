<div class="title">
    <h1>Lista de Cursos</h1>
</div>
<div class="table-container">
    <table id="coursesTable">
        <tr class="table-header">
            <th scope="col">Sigla</th>
            <th scope="col">Nome</th>
            <th scope="col"></th>
        </tr>
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr class="table-row">
            <td><?php echo e($course->abbreviation); ?></td>
            <td><?php echo e($course->name); ?></td>
            <td>
                <a href="<?php echo e(route('courses.show', $course->id)); ?>"><i class="fa-solid fa-magnifying-glass detailsBtn"  data-toggle="modal" data-target="#showModal"></i></a>
                <a href="<?php echo e(route('courses.edit', $course->id)); ?>"><i class="fa-solid fa-pencil editBtn"></i></a>
                <a onclick="event.preventDefault();
                   document.getElementById('courseRmvForm').submit();">
                    <i class="fa-regular fa-trash-can removeBtn"></i>
                </a>
                <form id="courseRmvForm" action="<?php echo e(route('courses.destroy', $course->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/courses/table.blade.php ENDPATH**/ ?>