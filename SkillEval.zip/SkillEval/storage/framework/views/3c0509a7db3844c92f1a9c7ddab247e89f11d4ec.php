<canvas class="student-eval-chart"   id="barChart">

    
</canvas>

<script>
    var ctx = document.getElementById('barChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [
                <?php $__currentLoopData = $studentEvaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    '<?php echo e($evaluation->test->type->type); ?>',
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            datasets: [{
                label: 'Nota',
                data: [
                    <?php $__currentLoopData = $studentEvaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        '<?php echo e($evaluation->score); ?>',
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                backgroundColor: [
         
                    <?php $__currentLoopData = $studentEvaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($evaluation->score >= 10): ?>
                            'rgba(0, 255, 0, 0.2)',
                        <?php else: ?>
                            'rgba(255, 0, 0, 0.2)',
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                borderColor: [
                    <?php $__currentLoopData = $studentEvaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($evaluation->score >= 10): ?>
                            'rgba(0, 255, 0, 1)',
                        <?php else: ?>
                            'rgba(255, 0, 0, 1)',
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    min: 0,
                    max: 20,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });

</script>

<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/students/evaluations-chart.blade.php ENDPATH**/ ?>