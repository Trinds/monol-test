<link rel="stylesheet" href="<?php echo e(asset('css/courses.css')); ?>">


<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.classrooms.add-form', ['courses' => $courses]); ?>
    
<?php if (isset($__componentOriginal217666aa0ffcfce86252969d63e86d61c73111e4)): ?>
<?php $component = $__componentOriginal217666aa0ffcfce86252969d63e86d61c73111e4; ?>
<?php unset($__componentOriginal217666aa0ffcfce86252969d63e86d61c73111e4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/classrooms/create.blade.php ENDPATH**/ ?>