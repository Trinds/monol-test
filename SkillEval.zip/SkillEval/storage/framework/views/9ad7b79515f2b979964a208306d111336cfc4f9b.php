<div class="dashboard-card <?php echo e($backgroundClass); ?>" onclick="location.href = '<?php echo e($dir); ?>'">
    <div class="left">
        <h1><?php echo e($count); ?></h1>
        <p><?php echo e($name); ?></p>
    </div>
    <div class="right">
        <i class="<?php echo e($iconClass); ?>"></i>
    </div>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/dashboard/dashboard-card.blade.php ENDPATH**/ ?>