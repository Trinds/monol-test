
<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard-container">

        <?php $__env->startComponent('components.dashboard.dashboard-card', [
            'backgroundClass' => 'background-gradient-light-orange',
            'count' => $studentsCount,
            'name' => 'Formandos',
            'iconClass' => 'fa-solid fa-user-graduate fa-2xl',
            'dir' => route('students.index'),
        ]); ?>
        <?php if (isset($__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130)): ?>
<?php $component = $__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130; ?>
<?php unset($__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('components.dashboard.dashboard-card', [
            'backgroundClass' => 'background-gradient-light-blue',
            'count' => $classroomsCount,
            'name' => 'Turmas',
            'iconClass' => 'fa-solid fa-users fa-2xl',
            'dir' => route('classrooms.index'),
        ]); ?>
        <?php if (isset($__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130)): ?>
<?php $component = $__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130; ?>
<?php unset($__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('components.dashboard.dashboard-card', [
            'backgroundClass' => 'background-gradient-dark-orange',
            'count' => $coursesCount,
            'name' => 'Cursos',
            'iconClass' => 'fa-regular fa-bookmark fa-2xl',
            'dir' => route('courses.index'),
        ]); ?>
        <?php if (isset($__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130)): ?>
<?php $component = $__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130; ?>
<?php unset($__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->roles->contains('name', 'admin')): ?>
                <?php $__env->startComponent('components.dashboard.dashboard-card', [
                    'backgroundClass' => 'background-gradient-dark-blue',
                    'count' => $usersCount,
                    'name' => 'Utilizadores',
                    'iconClass' => 'fa-regular fa-id-card fa-2xl',
                    'dir' => route('users.index'),
                ]); ?>
                <?php if (isset($__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130)): ?>
<?php $component = $__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130; ?>
<?php unset($__componentOriginal03be15e0abe533cd44fb2d08a62aacb156b59130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/home.blade.php ENDPATH**/ ?>