<div class="container">
    <div class="heading mb-3">
        <h1><?php echo e($course->abbreviation); ?></h1>
        <h5><?php echo e($course->name); ?></h5>
    </div>
    <div class="row">

        <?php if($course->classrooms->count() == 0): ?>
            <div class="alert alert-info" role="alert">
                Ainda não existem turmas para este curso.
            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $course->classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="grid-card">
                <div class="grid-card-img">
                    <img src="/imgs/classroom.png"/>
                </div>
                <div class="grid-card-details">
                    <p class="fw-bold mb-1"><?php echo e($classroom->course->abbreviation . ' ' . $classroom->edition); ?></p>
                    <p class="text-muted mb-0">Inicio: <?php echo e($classroom->start_date); ?></p>
                    <p class="text-muted mb-0">Fim: <?php echo e($classroom->end_date); ?> </p>
                    <p class="text-muted mb-0">Nº de alunos: <?php echo e($classroom->students->count()); ?></p>
                </div>
                <div class="grid-card-btns">
                    <a class="btn btn-link m-0 text-reset"
                       href="<?php echo e(route('classrooms.show', $classroom->id)); ?>"
                       role="button"
                       data-ripple-color="primary">Ver<i class="bi bi-search"></i></a>
                    <a class="btn btn-link m-0 text-reset"
                       href="<?php echo e(route('classrooms.edit', $classroom->id)); ?>"
                       role="button"
                       data-ripple-color="primary">Editar<i class="bi bi-pencil-fill"></i></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/courses/show-component.blade.php ENDPATH**/ ?>