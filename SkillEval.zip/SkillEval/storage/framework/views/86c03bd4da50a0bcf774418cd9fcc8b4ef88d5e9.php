

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/topbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('components.topbar',[
    'dir'           => 'classrooms',
    'createBtnName' => 'Turma',
    'courses'       => $courses,
    'filterName'    => 'Curso'
    ]); ?>
    <?php if (isset($__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14)): ?>
<?php $component = $__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14; ?>
<?php unset($__componentOriginal513a81e9ee751939fa9c72627a6c8d7013abef14); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.classrooms.table', ['classrooms' => $classrooms]); ?>
    <?php if (isset($__componentOriginalcbe8ecc36ff3f0ad09256bbd022fdead962a4e67)): ?>
<?php $component = $__componentOriginalcbe8ecc36ff3f0ad09256bbd022fdead962a4e67; ?>
<?php unset($__componentOriginalcbe8ecc36ff3f0ad09256bbd022fdead962a4e67); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/classrooms/index.blade.php ENDPATH**/ ?>