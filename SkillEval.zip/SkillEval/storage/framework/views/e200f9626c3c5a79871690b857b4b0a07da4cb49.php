<div class="title">
    <h1>Lista de Alunos</h1>
</div>
<div class="table-container">
    <table id="studentsTable">
        <tr class="table-header">
            <th></th>
            <th scope="col">Nome</th>
            <th scope="col">Email</th>
            <th scope="col">Data de Nascimento</th>
            <th scope="col">Turma</th>
            <th scope="col"></th>
        </tr>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table-row">
                <td><img src="<?php echo e($student->image); ?>" alt="Foto"></td>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->email); ?></td>
                <td><?php echo e(date('d-m-Y', strtotime($student->birth_date))); ?></td>
                <td><?php echo e($student->classroom->course->abbreviation . $student->classroom->edition); ?></td>
                <td>
                    <a href="<?php echo e(route('students.show', $student->id)); ?>"><i class="fa-solid fa-magnifying-glass detailsBtn"></i></a>
                    <a href="<?php echo e(route('students.edit', $student->id)); ?>"><i class="fa-solid fa-pencil editBtn"></i></a>
                    <a onclick="event.preventDefault();
                   document.getElementById('studentRmvForm').submit();">
                        <i class="fa-regular fa-trash-can removeBtn"></i>
                    </a>
                    <form id="studentRmvForm" action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/students/students-table.blade.php ENDPATH**/ ?>