

<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.classrooms.show-component', ['classroom' => $classroom]); ?>
    
<?php if (isset($__componentOriginal0abbfd36334b366658fa591aa114815bd62e6553)): ?>
<?php $component = $__componentOriginal0abbfd36334b366658fa591aa114815bd62e6553; ?>
<?php unset($__componentOriginal0abbfd36334b366658fa591aa114815bd62e6553); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/classrooms/show.blade.php ENDPATH**/ ?>