<link rel="stylesheet" href="<?php echo e(asset('css/courses.css')); ?>">


<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.courses.edit-form', ['course' => $course]); ?>
    
<?php if (isset($__componentOriginal8952b808d7743847a53ef03fb17fd9fbf51be50d)): ?>
<?php $component = $__componentOriginal8952b808d7743847a53ef03fb17fd9fbf51be50d; ?>
<?php unset($__componentOriginal8952b808d7743847a53ef03fb17fd9fbf51be50d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/courses/edit.blade.php ENDPATH**/ ?>