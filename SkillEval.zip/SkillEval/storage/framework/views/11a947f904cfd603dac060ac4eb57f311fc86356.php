

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/courses.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.courses.show-component', ['course' => $course]); ?>

<?php if (isset($__componentOriginal27b0f25f1f119d824e1b5f54983df4f9d21574eb)): ?>
<?php $component = $__componentOriginal27b0f25f1f119d824e1b5f54983df4f9d21574eb; ?>
<?php unset($__componentOriginal27b0f25f1f119d824e1b5f54983df4f9d21574eb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/courses/show.blade.php ENDPATH**/ ?>