<div class="container">        

    <form action="<?php echo e(url('courses')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h1>Adicionar curso</h1>

        <fieldset>
            <legend><span class="number">1</span> Informação do Curso</legend>

            <label for="name">Nome:</label>
            <input type="text" id="name" name="name" class="form-control"
            placeholder="Nome do curso"
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            value="<?php echo e(old('name')); ?>"
            required
            aria-describedat="nameHelp">
            <small id="nameHelp" class="form-text text-muted">Ex: Técnico Programação e Sistemas de Informação</small>
          
            <label for="abbreviation">Sigla:</label>
            <input type="text" id="abbreviation" name="abbreviation"
            class="form-control"
            placeholder="Sigla do curso"
            <?php $__errorArgs = ['abbreviation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            required
            aria-describedat="abbreviationHelp">
            <small id="abbreviationHelp" class="form-text text-muted">Ex: TPSI</small>
        
        </fieldset>
        <div class="form-group">
        <button type="submit">Adicionar</button>
        </div>
    </form>
</div>
<?php /**PATH C:\ATEC\MONOLITICO\SkillEval\resources\views/components/courses/add-form.blade.php ENDPATH**/ ?>